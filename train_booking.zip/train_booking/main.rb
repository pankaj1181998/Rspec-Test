require_relative 'Seat.rb'
require_relative 'RacSeats.rb'
require_relative 'Compartment.rb'

def allocationOfSeats
	compartment = Compartment.new
 	 110.times do |i|
	   compartment.allocate_seat i+1   
	 end
	 
	 50.times do |i|
	    compartment.cancel_seat i+1
	 end
	 
	 20.times do |i| 
	   compartment.allocate_seat i+1+20
	 end 

end 


allocationOfSeats  