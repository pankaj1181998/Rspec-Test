require_relative 'Seat.rb'
require_relative 'RacSeats.rb'

class Compartment

  NUM_SEATS = 54
  NUM_RAC_SEATS = 14
  MAX_WAITLIST_SIZE = 10


 ''' 
     initializes 
     @seat_num [seat_id]
     @customer_ids [customers on this seat] 
 '''
  def initialize()  

     @seats = []
     (1..NUM_SEATS).each do |i|
      @seats << Seat.new(i)
     end
 
     @rac_seats = []
     (1..NUM_RAC_SEATS).each do |i|
          @rac_seats << RacSeat.new(i)
     end 
     @customers_in_seats = []
     @customers_in_waitlist = []
     @customers_in_rac = []     
     p "Compartment initialized"

  end
  
  
  '''Allocates Seats to customers if avilable
   else return false '''
  def allocate_seat customer_id 
      seat_num = get_available_seat  
      if seat_num != nil then
          @seats[seat_num].allocate customer_id
          return true
      end      
 
      rac_seat_num = get_available_rac_seat
 
      if rac_seat_num != nil then
          @rac_seats[rac_seat_num].allocate customer_id
          @customers_in_rac << customer_id
          return true
      end      
 
      add_to_waitlist(customer_id)
  end

 '''cancels the seat and call for update
 of seats from rac and wailist'''
  def cancel_seat customer_id
       @seats.each_with_index do |seat, index| 
         if seat.cancel_reservation(customer_id) then
          update_rac_status if @customers_in_rac.size != 0 
          return true
        end
      end        
 
      @rac_seats.each_with_index do |seat, index| 
        if seat.cancel_reservation(customer_id) then
            # get 1st rac and upgrade its seat
            update_waitlist_status if  @customers_in_waitlist.size != 0
            return true
        end
      end

      if @customers_in_waitlist.include?(customer_id) then
         @customers_in_waitlist.delete(customer_id)
         return true
     end
     
     p "no booking still"    
     return false
  end 
  

  '''
    we have removed person from confirm list need to add one into confirm list
    get available seat  and allocate it to the person
    find the rac and remove his reservation
  '''
  def update_rac_status 
    return if @customers_in_rac.size == 0
    seat_num = get_available_seat
    return if seat_num == nil
    @seats[seat_num].allocate @customers_in_rac[0]

    @rac_seats.each do |seat|
      seat.cancel_reservation  @customers_in_rac[0]
    end
    @customers_in_rac = @customers_in_rac.drop(1)
    update_waitlist_status if @customers_in_waitlist.size != 0
  end
 
  '''
  updates waitlist after the cancellatin is made
  '''
  def update_waitlist_status     
    rac_seat_num = get_available_rac_seat
    return if rac_seat_num.nil?
    @rac_seats[rac_seat_num].allocate @customers_in_waitlist[0]   
    @customers_in_waitlist = @customers_in_waitlist.drop(1)
  end 
 

  def get_available_seat
      @seats.each_with_index do |seat, index| 
        return index if !seat.already_allocated
      end
      return nil
  end
 
  def get_available_rac_seat
      @rac_seats.each_with_index do |seat, index| 
        return index if !seat.already_allocated       
      end
      return nil
  end
 
  def add_to_waitlist customer_id
     if @customers_in_waitlist.size < MAX_WAITLIST_SIZE 
         p "cusomter added in waitlist"
         @customers_in_waitlist << customer_id
         return true
     end
         p "no availabilty of seats, sorry for inconvenience"
     return false     
  end
 
end
