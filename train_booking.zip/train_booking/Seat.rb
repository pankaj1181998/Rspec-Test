class Seat
  
  '''
     initializes 
     @seat_num [seat_id]
     @customer_ids [customers on this seat]
  '''
  def initialize seat_num
      @seat_num = seat_num  
      @customer_ids = []          
  end
 

  def allocate customer_id                                    
     if !already_allocated
         p "seat number: "+ @seat_num.to_s + "[" +seat_type + "] allocated to: " + customer_id.to_s
         @customer_ids << customer_id
         return true
     end
     return false
  end
 
  def already_allocated                     #check if the seat is already allocated or not
    return @customer_ids.size == 1
  end
 
  def cancel_reservation customer_id
    if @customer_ids.include?(customer_id)
        @customer_ids.delete(customer_id) 
         p "customer: "+ customer_id.to_s + " removed from: "+ @seat_num.to_s + "[" + seat_type + "] "
        return true
      end
    false
  end
  
 def seat_type
    "CONF"
 end

end
 
