require_relative 'Seat.rb'

class RacSeat < Seat  
  
  def already_allocated										#if seat is already allocated to
    return @customer_ids.size == 2
  end  
 
 def seat_type
    "RAC"
 end
end
 
